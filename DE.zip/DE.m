clc; clear; close all;
rng(1);

% ===== THAM SỐ CHUNG =====
D       = 2;
NP      = 40;
maxIter = 200;     % số vòng lặp
F       = 0.8;
CR      = 0.9;
lb      = -5.12;
ub      =  5.12;
A       = 10;

% ===== DANH SÁCH CÁC PHƯƠNG PHÁP =====
methods = {'rand1', 'best1', 'rand2', 'best2', 'currentToBest1'};
nM = numel(methods);

% ===== HÀM RASTRIGIN =====
rastrigin = @(x) A*D + sum(x.^2 - A*cos(2*pi*x));

% ===== KHỞI TẠO CHUNG (DÙNG CHO TẤT CẢ METHODS) =====
pop0 = lb + (ub-lb) * rand(NP, D);
fit0 = zeros(NP,1);
for i = 1:NP
    fit0(i) = rastrigin(pop0(i,:));
end

history = zeros(maxIter, nM);   % lưu best lịch sử cho từng method

% ===== CHẠY LẦN LƯỢT TỪNG PHƯƠNG PHÁP =====
for m = 1:nM
    method = methods{m};
    fprintf('=== Method: %s ===\n', method);

    % reset quần thể cho method này
    pop = pop0;
    fit = fit0;
    [bestVal, idx] = min(fit);
    bestSol = pop(idx,:);

    bestHistory = zeros(maxIter,1);

    % ----- VÒNG LẶP CHÍNH -----
    for iter = 1:maxIter
        for i = 1:NP

            % chọn chỉ số ngẫu nhiên
            idxs = randperm(NP);
            a = idxs(1);
            b = idxs(2);
            c = idxs(3);

            Xi = pop(i,:);

            % ----- ĐỘT BIẾN -----
            V = de_mutation(method, pop, a, b, c, idx, F);

            % Giữ trong miền
            V = max(V, lb);
            V = min(V, ub);

            % ----- LAI NHỊ PHÂN -----
            U = Xi;
            jrand = randi(D);
            for j = 1:D
                if rand <= CR || j == jrand
                    U(j) = V(j);
                end
            end

            % ----- CHỌN LỌC -----
            fU = rastrigin(U);
            if fU <= fit(i)
                pop(i,:) = U;
                fit(i) = fU;

                if fU < bestVal
                    bestVal = fU;
                    bestSol = U;
                    idx = i;
                end
            end
        end

        bestHistory(iter) = bestVal;
    end

    % lưu lịch sử cho method này
    history(:,m) = bestHistory;

    % in kết quả cuối cùng
    fprintf('  Best X = [%.6f , %.6f], f(X) = %.6f\n',...
        bestSol(1), bestSol(2), bestVal);
end

% ===== VẼ ĐỒ THỊ SO SÁNH =====
figure;
hold on;
for m = 1:nM
    plot(history(:,m), 'LineWidth', 1.5);
end
hold off;
xlabel('Iteration');
ylabel('Best f(x)');
title('So sánh các biến thể DE trên hàm Rastrigin (2D)');
legend(methods, 'Interpreter','none', 'Location', 'northeast');
grid on;
% ===== GẮN CHÚ THÍCH CHO TỪNG ĐƯỜNG NGAY TRÊN BIỂU ĐỒ =====
for m = 1:nM
    x_end = maxIter;
    y_end = history(end, m);
    text(x_end, y_end, ['  ' methods{m}], ...
        'FontSize', 9, 'Color', 'k', 'HorizontalAlignment','left');
end

% ===== THÊM CHÚ THÍCH NGẮN GỌN CHO CÁC PHƯƠNG PHÁP =====
noteText = {
    'DE/rand/1: Khởi tạo ngẫu nhiên + 1 sai phân'
    'DE/best/1: Dùng nghiệm tốt nhất + 1 sai phân'
    'DE/rand/2: Ngẫu nhiên + 2 sai phân'
    'DE/best/2: Tốt nhất + 2 sai phân'
    'DE/current-to-best/1: Hướng về nghiệm tốt nhất'
};

x_note = round(maxIter * 0.55);
y_max = max(max(history));

for k = 1:length(noteText)
    text(x_note, y_max * (1 - 0.1*k), noteText{k}, ...
        'FontSize', 9, 'Color', 'k');
end


% ===== HÀM PHỤ =====
function V = de_mutation(method, pop, a, b, c, bestIdx, F)

switch method
    case 'rand1'
        % DE/rand/1
        V = pop(a,:) + F * (pop(b,:) - pop(c,:));

    case 'best1'
        % DE/best/1
        best = pop(bestIdx,:);
        V = best + F * (pop(b,:) - pop(c,:));

    case 'rand2'
        % DE/rand/2
        idx = randperm(size(pop,1),5);
        r1=idx(1); r2=idx(2); r3=idx(3); r4=idx(4); r5=idx(5);
        V = pop(r1,:) + F * (pop(r2,:) - pop(r3,:) + pop(r4,:) - pop(r5,:));

    case 'best2'
        % DE/best/2
        best = pop(bestIdx,:);
        idx = randperm(size(pop,1),4);
        r1=idx(1); r2=idx(2); r3=idx(3); r4=idx(4);
        V = best + F * (pop(r1,:) - pop(r2,:) + pop(r3,:) - pop(r4,:));

    case 'currentToBest1'
        % DE/current-to-best/1
        V = pop(a,:) ...
          + F * (pop(bestIdx,:) - pop(a,:)) ...
          + F * (pop(b,:) - pop(c,:));
end

end
code này nói về gì